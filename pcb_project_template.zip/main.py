import os
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
from scipy.stats import kurtosis, skew
import matplotlib.pyplot as plt

img_size = (256, 256)
defective_path = "defective"
non_defective_path = "non_defective"

def load_and_preprocess(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, img_size)
    blurred = cv2.GaussianBlur(img, (5, 5), 0)
    return blurred

def compute_stats(image):
    flat = image.flatten()
    return {
        "mean": np.mean(flat),
        "var": np.var(flat),
        "skew": skew(flat),
        "kurtosis": kurtosis(flat)
    }

def detect_defects(image):
    local_thresh = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                         cv2.THRESH_BINARY_INV, 11, 2)
    contours, _ = cv2.findContours(local_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    result = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if w*h > 50:
            cv2.rectangle(result, (x, y), (x+w, y+h), (0, 0, 255), 2)
    return result, local_thresh

def calculate_ssim(img1, img2):
    score, _ = ssim(img1, img2, full=True)
    return score

def run_on_image_pairs():
    defective_files = sorted(os.listdir(defective_path))
    nondef_files = sorted(os.listdir(non_defective_path))

    for def_file, nondef_file in zip(defective_files, nondef_files):
        def_path = os.path.join(defective_path, def_file)
        nondef_path = os.path.join(non_defective_path, nondef_file)

        def_img = load_and_preprocess(def_path)
        nondef_img = load_and_preprocess(nondef_path)

        def_stats = compute_stats(def_img)
        nondef_stats = compute_stats(nondef_img)

        print(f"--- Comparing {def_file} vs {nondef_file} ---")
        print("Defective Stats:", def_stats)
        print("Non-Defective Stats:", nondef_stats)

        quality = calculate_ssim(def_img, nondef_img)
        print(f"SSIM Similarity: {quality:.4f}")

        result_img, thresh_img = detect_defects(def_img)

        plt.figure(figsize=(12, 4))
        plt.subplot(1, 3, 1)
        plt.title("Defective Image")
        plt.imshow(def_img, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 2)
        plt.title("Thresholded")
        plt.imshow(thresh_img, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 3)
        plt.title("Defect Detection")
        plt.imshow(result_img)
        plt.axis('off')

        plt.tight_layout()
        plt.show()
        input("Press Enter for next image...\n")

run_on_image_pairs()
